<template>
    <div>
        This is register page
    </div>
</template>