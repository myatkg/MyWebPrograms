<template>
    <div>
        <coach-filter @change-filter="setFilter"></coach-filter>
        <base-card>
            <div class="controls">
                <base-button mode="outline">Refresh</base-button>
                <base-button link to="/register">Register for Coach</base-button>  
            </div>
            <ul v-if="hasCoaches">
                <coach-items 
                    v-for="coach in filteredCoaches" 
                    :key="coach.id" :id="coach.id" 
                    :first-name="coach.firstName" 
                    :last-name="coach.lastName"
                    :rate="coach.hourlyRate"
                    :areas="coach.areas">
                </coach-items>
            </ul>
            <ul v-else>
                No coaches found
            </ul> 
        </base-card>
    </div>
</template>

<script>
import CoachItems from '@/components/coaches/CoachItems.vue';
import CoachFilter from '@/components/coaches/CoachFilter.vue';

export default {
    data() {
        return {
            activeFilters: {
                frontend: true,
                backend: true,
                career: true
            }
        };
    },
    components: {
        CoachItems, 
        CoachFilter
        },
    computed: {
        filteredCoaches() {
            const coaches = this.$store.getters['coaches/coaches'] //['namespace/getter name']
            return coaches.filter(coach => {
                if(this.activeFilters.frontend && coach.areas.includes('frontend')) {
                    return true;
                }
                if(this.activeFilters.backend && coach.areas.includes('backend')) {
                    return true;
                }
                if(this.activeFilters.career && coach.areas.includes('career')) {
                    return true;
                }
                return false;
            }); 
        },
        hasCoaches() {
            return this.$store.getters['coaches/hasCoaches'];
        },
        methods: {
            setFilter(updatedFilter) {
                this.activeFilters = updatedFilter;
            }
        }
    }
}
</script>

<style scoped>
ul {
  list-style: none;
  margin: 0;
  padding: 0;
}

.controls {
  display: flex;
  justify-content: space-between;
}
</style>